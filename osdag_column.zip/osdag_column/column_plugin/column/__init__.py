"""
Column module for compression member design
"""
