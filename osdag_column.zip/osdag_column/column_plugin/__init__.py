"""
Column Plugin for Osdag
Adds Column design module to Compression Member module

Author: Osdag Team
Version: 0.1.0
"""

from .plugin import ColumnPlugin

plugin_class = ColumnPlugin
