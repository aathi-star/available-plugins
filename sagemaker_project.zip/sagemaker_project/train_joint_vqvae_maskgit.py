"""
Joint Training Script for VQ-VAE and MaskGIT3D
Trains both models end-to-end on 3D point cloud data
"""
import os
import sys
import time
import json
import argparse
import numpy as np
from tqdm import tqdm
from pathlib import Path
from datetime import datetime

import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.distributed as dist
from torch.cuda.amp import GradScaler, autocast
from torch.utils.tensorboard import SummaryWriter

# Add project root to path
sys.path.append(str(Path(__file__).parent.absolute()))

from Network.transformer_3d import MaskGIT3D
from Network.point_vqvae import PointVQVAE
from datasets.modelnet_loader import ModelNet10Dataset
from utils.vq_utils import point_clouds_to_voxels, voxels_to_point_clouds

def parse_args():
    parser = argparse.ArgumentParser(description='Joint Training of VQ-VAE and MaskGIT3D')
    
    # Model parameters
    parser.add_argument('--embed_dim', type=int, default=256, help='Model embedding dimension')
    parser.add_argument('--depth', type=int, default=4, help='Number of transformer layers')
    parser.add_argument('--heads', type=int, default=4, help='Number of attention heads')
    parser.add_argument('--mlp_ratio', type=float, default=4.0, help='MLP ratio in transformer')
    parser.add_argument('--drop_rate', type=float, default=0.1, help='Dropout rate')
    
    # VQ-VAE parameters
    parser.add_argument('--vq_codebook_size', type=int, default=1024, help='VQ-VAE codebook size')
    parser.add_argument('--vq_embed_dim', type=int, default=256, help='VQ-VAE embedding dimension')
    parser.add_argument('--vq_beta', type=float, default=0.25, help='VQ-VAE commitment cost')
    
    # Training parameters
    parser.add_argument('--batch_size', type=int, default=32, help='Batch size per GPU')
    parser.add_argument('--epochs', type=int, default=500, help='Number of training epochs')
    parser.add_argument('--lr_vqvae', type=float, default=1e-4, help='VQ-VAE learning rate')
    parser.add_argument('--lr_maskgit', type=float, default=1e-4, help='MaskGIT learning rate')
    parser.add_argument('--weight_decay', type=float, default=0.05, help='Weight decay')
    parser.add_argument('--warmup_epochs', type=int, default=10, help='Warmup epochs')
    parser.add_argument('--min_lr', type=float,=1e-6, help='Minimum learning rate')
    parser.add_argument('--clip_grad', type=float,=1.0, help='Gradient clipping')
    
    # Loss weights
    parser.add_argument('--recon_weight', type=float, default=1.0, help='Reconstruction loss weight')
    parser.add_argument('--vq_weight', type=float, default=1.0, help='VQ loss weight')
    parser.add_argument('--maskgit_weight', type=float, default=1.0, help='MaskGIT loss weight')
    
    # Masking parameters
    parser.add_argument('--mask_ratio', type=float, default=0.5, help='Masking ratio')
    parser.add_argument('--mask_strategy', type=str, default='halton', 
                        choices=['random', 'halton', 'learned'], help='Masking strategy')
    
    # Dataset parameters
    parser.add_argument('--data_dir', type=str, default='./data/ModelNet10', 
                       help='Path to ModelNet10 dataset')
    parser.add_argument('--num_points', type=int, default=1024, help='Number of points per sample')
    parser.add_argument('--num_workers', type=int, default=4, help='Number of data loading workers')
    
    # Logging and saving
    parser.add_argument('--output_dir', type=str, default='./output_joint', help='Output directory')
    parser.add_argument('--log_dir', type=str, default='./logs_joint', help='Log directory')
    parser.add_argument('--save_freq', type=int, default=10, help='Save frequency (epochs)')
    parser.add_argument('--print_freq', type=int, default=10, help='Print frequency (iterations)')
    
    # System parameters
    parser.add_argument('--device', type=str, default='cuda' if torch.cuda.is_available() else 'cpu',
                       help='Device to use for training')
    parser.add_argument('--seed', type=int, default=42, help='Random seed')
    parser.add_argument('--fp16', action='store_true', help='Use mixed precision training')
    
    return parser.parse_args()

class JointModel(nn.Module):
    def __init__(self, args):
        super().__init__()
        self.args = args
        
        # Create VQ-VAE
        self.vqvae = PointVQVAE(
            in_channels=3,  # x, y, z coordinates
            hidden_dims=[64, 128, 256],
            embed_dim=args.vq_embed_dim,
            n_embed=args.vq_codebook_size,
            beta=args.vq_beta
        )
        
        # Create MaskGIT3D
        self.maskgit = MaskGIT3D(
            embed_dim=args.embed_dim,
            depth=args.depth,
            num_heads=args.heads,
            mlp_ratio=args.mlp_ratio,
            drop_rate=args.drop_rate,
            num_classes=args.vq_codebook_size,  # Predict VQ-VAE codebook indices
            mask_ratio=args.mask_ratio,
            mask_strategy=args.mask_strategy
        )
        
        # Initialize weights
        self._init_weights()
    
    def _init_weights(self):
        # Initialize VQ-VAE weights
        def init_vqvae_weights(m):
            if isinstance(m, nn.Conv3d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.BatchNorm3d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)
        
        self.vqvae.apply(init_vqvae_weights)
        
        # Initialize MaskGIT3D weights
        def init_maskgit_weights(m):
            if isinstance(m, nn.Linear):
                nn.init.xavier_uniform_(m.weight)
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.LayerNorm):
                nn.init.constant_(m.weight, 1.0)
                nn.init.constant_(m.bias, 0)
        
        self.maskgit.apply(init_maskgit_weights)
    
    def encode(self, points):
        """Encode point clouds to codebook indices"""
        # Convert points to voxel grid
        voxels = point_clouds_to_voxels(points, grid_size=32)
        
        # Encode to get codebook indices
        _, _, codebook_indices = self.vqvae.encode(voxels)
        return codebook_indices
    
    def decode(self, codebook_indices):
        """Decode codebook indices to point clouds"""
        # Convert indices to voxel grid
        batch_size = codebook_indices.size(0)
        shape = (batch_size, self.args.vq_embed_dim, 8, 8, 8)  # Adjust based on your VQ-VAE
        voxels = self.vqvae.decode_indices(codebook_indices, shape)
        
        # Convert voxel grid to point cloud
        points = voxels_to_point_clouds(voxels)
        return points
    
    def forward(self, points, labels=None):
        """
        Forward pass for joint training
        
        Args:
            points: Input point clouds (B, N, 3)
            labels: Optional class labels (B,)
            
        Returns:
            dict: Dictionary containing losses and outputs
        """
        # VQ-VAE forward pass
        voxels = point_clouds_to_voxels(points, grid_size=32)
        recon_voxels, vq_loss, codebook_indices = self.vqvae(voxels)
        
        # Calculate reconstruction loss
        recon_loss = F.mse_loss(recon_voxels, voxels)
        
        # MaskGIT forward pass
        logits, mask = self.maskgit(points, labels=labels)
        
        # Calculate MaskGIT loss (predict codebook indices)
        targets = codebook_indices.view(-1)  # (B*S,)
        logits = logits.view(-1, logits.size(-1))  # (B*S, codebook_size)
        maskgit_loss = F.cross_entropy(logits, targets, reduction='none')
        maskgit_loss = (maskgit_loss * mask.view(-1)).sum() / (mask.sum() + 1e-8)
        
        # Combine losses
        loss = (
            self.args.recon_weight * recon_loss +
            self.args.vq_weight * vq_loss +
            self.args.maskgit_weight * maskgit_loss
        )
        
        return {
            'loss': loss,
            'recon_loss': recon_loss,
            'vq_loss': vq_loss,
            'maskgit_loss': maskgit_loss,
            'codebook_indices': codebook_indices,
            'mask': mask
        }

def prepare_dataloaders(args):
    """Prepare training and validation dataloaders"""
    from torch.utils.data import DataLoader, random_split
    from torch.utils.data.distributed import DistributedSampler
    
    # Create full dataset
    full_dataset = ModelNet10Dataset(
        root=args.data_dir,
        split='trainval',  # Use both train and validation splits
        num_points=args.num_points,
        use_normalized_coords=True
    )
    
    # Split into train and validation
    val_size = int(0.1 * len(full_dataset))  # 10% for validation
    train_size = len(full_dataset) - val_size
    train_dataset, val_dataset = random_split(
        full_dataset, [train_size, val_size],
        generator=torch.Generator().manual_seed(args.seed)
    )
    
    # Create dataloaders
    train_loader = DataLoader(
        train_dataset,
        batch_size=args.batch_size,
        shuffle=True,
        num_workers=args.num_workers,
        pin_memory=True,
        drop_last=True
    )
    
    val_loader = DataLoader(
        val_dataset,
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=args.num_workers,
        pin_memory=True,
        drop_last=False
    )
    
    return train_loader, val_loader

def train_epoch(model, optimizer, scaler, dataloader, epoch, args):
    """Train for one epoch with gradient accumulation"""
    model.train()
    
    total_loss = 0.0
    total_recon_loss = 0.0
    total_vq_loss = 0.0
    total_maskgit_loss = 0.0
    total_items = 0
    accumulated_steps = 0
    
    # Gradient accumulation
    accumulation_steps = args.get('grad_accumulation', 1)
    optimizer.zero_grad()
    
    # Progress bar
    pbar = tqdm(dataloader, desc=f'Epoch {epoch+1}/{args.epochs} [Train]', dynamic_ncols=True)
    
    for batch_idx, batch in enumerate(pbar):
        # Move data to device
        points = batch['points'].to(args.device)  # (B, N, 3)
        labels = batch.get('label', None)
        if labels is not None:
            labels = labels.to(args.device)
        
        # Forward pass with mixed precision
        with autocast(enabled=args.fp16):
            outputs = model(points, labels=labels)
            loss = outputs['loss'] / accumulation_steps
        
        # Backward pass with gradient accumulation
        if args.fp16:
            scaler.scale(loss).backward()
        else:
            loss.backward()
        
        # Perform optimization step after accumulation steps
        if (batch_idx + 1) % accumulation_steps == 0 or (batch_idx + 1) == len(dataloader):
            # Gradient clipping
            if args.fp16:
                scaler.unscale_(optimizer)
            
            if args.get('clip_grad') is not None:
                grad_norm = torch.nn.utils.clip_grad_norm_(
                    model.parameters(), 
                    args.clip_grad
                )
                
                # Skip batch if gradients are too large
                if args.get('grad_skip_threshold') and grad_norm > args.grad_skip_threshold:
                    optimizer.zero_grad()
                    print(f'Skipping batch {batch_idx} - Gradient norm too large: {grad_norm:.2f}')
                    continue
            
            # Optimizer step
            if args.fp16:
                scaler.step(optimizer)
                scaler.update()
            else:
                optimizer.step()
            
            optimizer.zero_grad()
            accumulated_steps += 1
        
        # Update metrics (scale loss back up for logging)
        batch_size = points.size(0)
        total_loss += loss.item() * batch_size * accumulation_steps
        total_recon_loss += outputs['recon_loss'].item() * batch_size
        total_vq_loss += outputs['vq_loss'].item() * batch_size
        total_maskgit_loss += outputs['maskgit_loss'].item() * batch_size
        total_items += batch_size
        
        # Log progress
        if (batch_idx + 1) % args.get('log_interval', 10) == 0:
            pbar.set_postfix({
                'loss': f"{total_loss/total_items:.4f}",
                'recon': f"{total_recon_loss/total_items:.4f}",
                'vq': f"{total_vq_loss/total_items:.4f}",
                'maskgit': f"{total_maskgit_loss/total_items:.4f}",
                'lr': optimizer.param_groups[0]['lr']
            })
    
    # Calculate epoch metrics
    metrics = {
        'loss': total_loss / total_items if total_items > 0 else 0.0,
        'recon_loss': total_recon_loss / total_items if total_items > 0 else 0.0,
        'vq_loss': total_vq_loss / total_items if total_items > 0 else 0.0,
        'maskgit_loss': total_maskgit_loss / total_items if total_items > 0 else 0.0,
    }
    
    return metrics

@torch.no_grad()
def validate(model, vqvae, criterion, dataloader, args):
    model.eval()
    vqvae.eval()
    
    total_loss = 0.0
    total_items = 0
    
    for batch in dataloader:
        points = batch['points'].to(args.device)
        
        # Encode point clouds
        with torch.no_grad():
            codebook_indices = encode_point_clouds(vqvae, points, args.device)
        
        # Forward pass
        with autocast(enabled=args.fp16):
            logits = model(points, mask_ratio=args.max_mask_ratio)  # Use max mask ratio for validation
            logits = logits.view(-1, logits.size(-1))
            targets = codebook_indices.view(-1).long()
            loss = criterion(logits, targets)
        
        # Update metrics
        batch_size = points.size(0)
        total_loss += loss.item() * batch_size
        total_items += batch_size
    
    return total_loss / total_items if total_items > 0 else 0.0

def save_checkpoint(state, filename):
    """Save training checkpoint"""
    torch.save(state, filename)

def main():
    # Parse arguments
    args = parse_args()
    
    # Set random seed
    torch.manual_seed(args.seed)
    np.random.seed(args.seed)
    
    # Create output directories
    os.makedirs(args.output_dir, exist_ok=True)
    os.makedirs(args.log_dir, exist_ok=True)
    
    # Save config
    with open(os.path.join(args.output_dir, 'config.json'), 'w') as f:
        json.dump(vars(args), f, indent=2)
    
    # Initialize TensorBoard writer
    writer = SummaryWriter(log_dir=args.log_dir)
    
    # Create model
    print("Creating joint VQ-VAE + MaskGIT3D model...")
    model = JointModel(args).to(args.device)
    
    # Print model summary
    total_params = sum(p.numel() for p in model.parameters())
    print(f"Total parameters: {total_params/1e6:.2f}M")
    
    # Create optimizer with separate learning rates
    optimizer = torch.optim.AdamW(
        [
            {'params': model.vqvae.parameters(), 'lr': args.lr_vqvae},
            {'params': model.maskgit.parameters(), 'lr': args.lr_maskgit}
        ],
        weight_decay=args.weight_decay,
        betas=(0.9, 0.95)
    )
    
    # Learning rate scheduler
    def lr_lambda(epoch):
        if epoch < args.warmup_epochs:
            return epoch / args.warmup_epochs
        progress = (epoch - args.warmup_epochs) / (args.epochs - args.warmup_epochs)
        return max(args.min_lr / args.lr_vqvae, 0.5 * (1.0 + np.cos(np.pi * progress)))
    
    scheduler = torch.optim.lr_scheduler.LambdaLR(optimizer, lr_lambda)
    
    # Gradient scaler for mixed precision training
    scaler = GradScaler(enabled=args.fp16)
    
    # Prepare dataloaders
    print("Preparing dataloaders...")
    train_loader, val_loader = prepare_dataloaders(args)
    
    # Training loop
    print("Starting training...")
    best_val_loss = float('inf')
    
    for epoch in range(args.epochs):
        # Train for one epoch
        train_metrics = train_epoch(model, optimizer, scaler, train_loader, epoch, args)
        
        # Validate
        val_metrics = validate(model, val_loader, args)
        
        # Update learning rate
        scheduler.step()
        
        # Log metrics
        for k, v in train_metrics.items():
            writer.add_scalar(f'train/{k}', v, epoch)
        for k, v in val_metrics.items():
            writer.add_scalar(f'val/{k}', v, epoch)
        
        # Log learning rates
        for i, param_group in enumerate(optimizer.param_groups):
            writer.add_scalar(f'lr/group_{i}', param_group['lr'], epoch)
        
        # Save checkpoint
        is_best = val_metrics['val_loss'] < best_val_loss
        best_val_loss = min(best_val_loss, val_metrics['val_loss'])
        
        if (epoch + 1) % args.save_freq == 0 or is_best or (epoch == args.epochs - 1):
            checkpoint = {
                'epoch': epoch,
                'state_dict': model.state_dict(),
                'optimizer': optimizer.state_dict(),
                'scheduler': scheduler.state_dict(),
                'scaler': scaler.state_dict() if args.fp16 else None,
                'best_val_loss': best_val_loss,
                'args': args
            }
            
            # Save checkpoint
            checkpoint_path = os.path.join(args.output_dir, f'checkpoint_epoch_{epoch+1:04d}.pth')
            save_checkpoint(checkpoint, checkpoint_path)
            
            if is_best:
                best_path = os.path.join(args.output_dir, 'model_best.pth')
                torch.save(checkpoint, best_path)
    
    # Close TensorBoard writer
    writer.close()
    print("Training completed!")

if __name__ == '__main__':
    main()
