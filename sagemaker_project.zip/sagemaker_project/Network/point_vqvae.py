"""
3D Point Cloud VQ-VAE implementation for MaskGIT3D
Based on Point-VQVAE architecture
"""
import torch
import torch.nn as nn
import torch.nn.functional as F
from einops import rearrange

class VectorQuantizer(nn.Module):
    """
    Discretization bottleneck part of the VQ-VAE.
    Inputs:
    - n_e : number of embeddings
    - e_dim : dimension of embedding
    - beta : commitment cost used in loss term, beta * ||z_e(x)-sg[e]||^2
    """
    def __init__(self, n_e=1024, e_dim=256, beta=0.25):
        super().__init__()
        self.n_e = n_e
        self.e_dim = e_dim
        self.beta = beta

        self.embedding = nn.Embedding(self.n_e, self.e_dim)
        self.embedding.weight.data.uniform_(-1.0 / self.n_e, 1.0 / self.n_e)

    def forward(self, z):
        # reshape z -> (batch, height, width, channel) and flatten
        z = z.permute(0, 2, 3, 4, 1).contiguous()
        z_flattened = z.view(-1, self.e_dim)
        
        # distances from z to embeddings e_j (z - e)^2 = z^2 + e^2 - 2 e * z
        d = (z_flattened ** 2).sum(dim=1, keepdim=True) + \
            (self.embedding.weight ** 2).sum(1) - 2 * \
            torch.matmul(z_flattened, self.embedding.weight.t())
            
        # find closest encodings
        min_encoding_indices = torch.argmin(d, dim=1).unsqueeze(1)
        min_encodings = torch.zeros(min_encoding_indices.shape[0], self.n_e, device=z.device)
        min_encodings.scatter_(1, min_encoding_indices, 1)
        
        # get quantized latent vectors
        z_q = torch.matmul(min_encodings, self.embedding.weight).view(z.shape)
        
        # compute loss for embedding
        loss = self.beta * torch.mean((z_q.detach() - z) ** 2) + \
               torch.mean((z_q - z.detach()) ** 2)
        
        # preserve gradients
        z_q = z + (z_q - z).detach()
        
        # reshape back to match original input shape
        z_q = z_q.permute(0, 4, 1, 2, 3).contiguous()
        
        return z_q, loss, min_encoding_indices.view(z.size(0), -1)

    def get_codebook_entry(self, indices, shape):
        # shape specifying (batch, height, width, depth)
        indices = indices.view(-1)
        min_encodings = torch.zeros(indices.shape[0], self.n_e, device=indices.device)
        min_encodings.scatter_(1, indices.unsqueeze(1), 1)
        # get quantized latent vectors
        z_q = torch.matmul(min_encodings.float(), self.embedding.weight)
        z_q = z_q.view(shape[0], shape[2], shape[3], shape[4], -1).permute(0, 4, 1, 2, 3).contiguous()
        return z_q

class ResnetBlock3D(nn.Module):
    def __init__(self, in_channels, out_channels=None, dropout=0.1):
        super().__init__()
        self.in_channels = in_channels
        out_channels = in_channels if out_channels is None else out_channels
        
        self.norm1 = nn.GroupNorm(32, in_channels)
        self.conv1 = nn.Conv3d(in_channels, out_channels, kernel_size=3, stride=1, padding=1)
        self.dropout = nn.Dropout(dropout)
        self.conv2 = nn.Conv3d(out_channels, out_channels, kernel_size=3, stride=1, padding=1)
        self.norm2 = nn.GroupNorm(32, out_channels)
        
        if in_channels != out_channels:
            self.shortcut = nn.Conv3d(in_channels, out_channels, kernel_size=1, stride=1, padding=0)
        else:
            self.shortcut = nn.Identity()
            
    def forward(self, x):
        h = x
        h = self.norm1(h)
        h = F.silu(h)
        h = self.conv1(h)
        
        h = self.norm2(h)
        h = F.silu(h)
        h = self.dropout(h)
        h = self.conv2(h)
        
        return h + self.shortcut(x)

class PointVQVAE(nn.Module):
    def __init__(self, 
                 in_channels=3, 
                 hidden_dims=[64, 128, 256],
                 embed_dim=256,
                 n_embed=1024,
                 beta=0.25,
                 dropout=0.1):
        super().__init__()
        
        # Encoder
        modules = []
        in_ch = in_channels
        
        # Build Encoder
        for h_dim in hidden_dims:
            modules.append(
                nn.Sequential(
                    nn.Conv3d(in_ch, h_dim, kernel_size=4, stride=2, padding=1),
                    ResnetBlock3D(h_dim, dropout=dropout),
                    ResnetBlock3D(h_dim, dropout=dropout)
                )
            )
            in_ch = h_dim
            
        self.encoder = nn.Sequential(*modules)
        
        # Pre-quantization conv
        self.pre_quant = nn.Conv3d(hidden_dims[-1], embed_dim, 1)
        
        # Vector Quantizer
        self.quantize = VectorQuantizer(n_embed, embed_dim, beta)
        
        # Post-quantization conv
        self.post_quant = nn.Conv3d(embed_dim, hidden_dims[-1], 1)
        
        # Decoder
        modules = []
        
        # Build Decoder
        hidden_dims = [hidden_dims[-1]] + hidden_dims[:-1][::-1]
        
        for i, h_dim in enumerate(hidden_dims[:-1]):
            modules.append(
                nn.Sequential(
                    nn.ConvTranspose3d(h_dim, hidden_dims[i+1], 
                                      kernel_size=4, stride=2, padding=1, output_padding=0),
                    ResnetBlock3D(hidden_dims[i+1], dropout=dropout),
                    ResnetBlock3D(hidden_dims[i+1], dropout=dropout)
                )
            )
            
        self.decoder = nn.Sequential(*modules)
        
        # Final layer
        self.final_layer = nn.Sequential(
            nn.Conv3d(hidden_dims[-1], hidden_dims[-1], kernel_size=3, stride=1, padding=1),
            nn.GroupNorm(32, hidden_dims[-1]),
            nn.SiLU(),
            nn.Conv3d(hidden_dims[-1], in_channels, kernel_size=3, stride=1, padding=1)
        )
        
    def encode(self, x):
        """Encodes the input by passing through the encoder network and returns the latent codes."""
        h = self.encoder(x)
        h = self.pre_quant(h)
        z_q, vq_loss, encoding_indices = self.quantize(h)
        return z_q, vq_loss, encoding_indices
    
    def decode(self, z):
        """Maps the given latent codes onto the point cloud space."""
        h = self.post_quant(z)
        h = self.decoder(h)
        result = self.final_layer(h)
        return result
    
    def forward(self, x):
        z_q, vq_loss, encoding_indices = self.encode(x)
        recon = self.decode(z_q)
        return recon, vq_loss, encoding_indices
    
    def get_codebook_indices(self, x):
        """Returns the codebook indices for the input."""
        h = self.encoder(x)
        h = self.pre_quant(h)
        _, _, encoding_indices = self.quantize(h)
        return encoding_indices
    
    def decode_indices(self, indices, shape):
        """Decodes the codebook indices to point clouds."""
        # shape: (batch_size, D, H, W, C)
        z_q = self.quantize.get_codebook_entry(indices, shape)
        dec = self.decode(z_q)
        return dec

def load_pretrained_vqvae(ckpt_path, device='cuda'):
    """Load a pre-trained VQ-VAE model."""
    model = PointVQVAE(
        in_channels=3,
        hidden_dims=[64, 128, 256],
        embed_dim=256,
        n_embed=1024,
        beta=0.25
    )
    
    # Load pre-trained weights if path is provided
    if ckpt_path is not None:
        state_dict = torch.load(ckpt_path, map_location='cpu')
        if 'state_dict' in state_dict:
            state_dict = state_dict['state_dict']
        model.load_state_dict(state_dict, strict=True)
    
    model = model.to(device)
    model.eval()
    return model
