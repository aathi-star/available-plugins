"""
Utilities for working with VQ-VAE and MaskGIT3D integration
"""
import torch
import torch.nn as nn
from pathlib import Path
import os

from Network.point_vqvae import PointVQVAE, load_pretrained_vqvae

def get_vqvae_model(ckpt_path=None, device='cuda'):
    """
    Load or initialize a VQ-VAE model.
    If ckpt_path is provided, loads pre-trained weights.
    Otherwise, initializes a new model.
    """
    model = PointVQVAE(
        in_channels=3,  # xyz coordinates
        hidden_dims=[64, 128, 256],
        embed_dim=256,
        n_embed=1024,  # Matches MaskGIT3D's expected codebook size
        beta=0.25
    )
    
    # Load pre-trained weights if path is provided
    if ckpt_path is not None and os.path.exists(ckpt_path):
        print(f"Loading VQ-VAE weights from {ckpt_path}")
        state_dict = torch.load(ckpt_path, map_location='cpu')
        
        # Handle different checkpoint formats
        if 'state_dict' in state_dict:
            state_dict = state_dict['state_dict']
            
        # Remove 'module.' prefix if present (for DDP models)
        state_dict = {k.replace('module.', ''): v for k, v in state_dict.items()}
        
        # Load state dict
        model.load_state_dict(state_dict, strict=True)
    else:
        print("Initializing VQ-VAE with random weights")
    
    model = model.to(device)
    model.eval()
    return model

def encode_point_clouds(vqvae, point_clouds, device='cuda'):
    """
    Encode point clouds to latent codes using VQ-VAE
    
    Args:
        vqvae: Pre-trained VQ-VAE model
        point_clouds: Input point clouds (B, N, 3)
        
    Returns:
        codebook_indices: (B, seq_len) tensor of codebook indices
        vq_loss: Vector quantization loss
    """
    # Convert point clouds to voxel grid
    # This is a simplified version - you might need to adjust based on your data
    voxels = point_clouds_to_voxels(point_clouds, grid_size=32)
    voxels = voxels.to(device)
    
    # Encode to latent space
    with torch.no_grad():
        _, _, codebook_indices = vqvae.encode(voxels)
        
    return codebook_indices

def decode_to_point_clouds(vqvae, codebook_indices, device='cuda'):
    """
    Decode codebook indices back to point clouds
    
    Args:
        vqvae: Pre-trained VQ-VAE model
        codebook_indices: (B, seq_len) tensor of codebook indices
        
    Returns:
        point_clouds: Reconstructed point clouds (B, N, 3)
    """
    batch_size = codebook_indices.size(0)
    seq_len = codebook_indices.size(1)
    
    # Reshape indices for VQ-VAE
    # This assumes the spatial dimensions are flattened in the sequence
    # Adjust based on your actual sequence structure
    grid_size = int((seq_len) ** (1/3))  # Assuming cubic volume
    shape = (batch_size, 256, grid_size, grid_size, grid_size)  # 256 is the channel dim in VQ-VAE
    
    with torch.no_grad():
        # Convert indices to voxel grid
        voxels = vqvae.decode_indices(codebook_indices, shape)
        
        # Convert voxel grid back to point cloud
        point_clouds = voxels_to_point_clouds(voxels)
        
    return point_clouds

def point_clouds_to_voxels(points, grid_size=32):
    """
    Convert point clouds to voxel grid representation
    
    Args:
        points: (B, N, 3) tensor of point clouds in [-1, 1] range
        grid_size: Size of the voxel grid
        
    Returns:
        voxels: (B, 3, grid_size, grid_size, grid_size) tensor
    """
    device = points.device
    batch_size = points.size(0)
    
    # Normalize points to [0, grid_size-1]
    points = (points + 1) * 0.5  # to [0, 1]
    points = points * (grid_size - 1)  # to [0, grid_size-1]
    
    # Initialize voxel grid
    voxels = torch.zeros(batch_size, 3, grid_size, grid_size, grid_size, device=device)
    
    # Get indices
    x = points[..., 0].long()
    y = points[..., 1].long()
    z = points[..., 2].long()
    
    # Clamp indices to valid range
    x = torch.clamp(x, 0, grid_size-1)
    y = torch.clamp(y, 0, grid_size-1)
    z = torch.clamp(z, 0, grid_size-1)
    
    # Set occupied voxels
    for b in range(batch_size):
        voxels[b, :, x[b], y[b], z[b]] = 1.0
        
    return voxels

def voxels_to_point_clouds(voxels, threshold=0.5):
    """
    Convert voxel grid to point cloud
    
    Args:
        voxels: (B, C, D, H, W) tensor of voxel probabilities
        threshold: Occupancy threshold
        
    Returns:
        points: (B, N, 3) tensor of point clouds
    """
    device = voxels.device
    batch_size = voxels.size(0)
    
    # Threshold to get binary occupancy
    occupancy = (voxels > threshold).float()
    
    batch_points = []
    for b in range(batch_size):
        # Get indices of occupied voxels
        indices = torch.nonzero(occupancy[b, 0] > 0.5, as_tuple=False).float()
        
        # Normalize to [-1, 1]
        grid_size = voxels.size(2)
        points = (indices / (grid_size - 1)) * 2 - 1
        batch_points.append(points)
    
    # Pad point clouds to have the same number of points
    max_points = max(p.size(0) for p in batch_points)
    padded_points = []
    for points in batch_points:
        if points.size(0) < max_points:
            # Pad with zeros
            padding = torch.zeros(max_points - points.size(0), 3, device=device)
            points = torch.cat([points, padding], dim=0)
        padded_points.append(points)
    
    return torch.stack(padded_points, dim=0)
