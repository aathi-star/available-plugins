"""
Adaptive Halton sampling for 3D point cloud masking
"""
import torch
import torch.nn.functional as F
import numpy as np
from scipy.spatial import cKDTree

class AdaptiveHaltonSampler:
    def __init__(self, k_neighbors=16, bandwidth=0.1, eps=1e-8):
        """
        Initialize adaptive Halton sampler.
        
        Args:
            k_neighbors: Number of neighbors for density estimation
            bandwidth: Kernel bandwidth for density estimation
            eps: Small constant for numerical stability
        """
        self.k_neighbors = k_neighbors
        self.bandwidth = bandwidth
        self.eps = eps
        self.halton_sampler = Halton3DSampler()
        
    def estimate_point_density(self, points):
        """
        Estimate density at each point using KDE (Kernel Density Estimation).
        
        Args:
            points: Tensor of shape [B, N, 3] or [N, 3]
            
        Returns:
            densities: Tensor of shape [B, N] or [N] with density estimates
        """
        if len(points.shape) == 2:
            points = points.unsqueeze(0)  # Add batch dim if needed
            squeeze = True
        else:
            squeeze = False
            
        B, N, _ = points.shape
        device = points.device
        densities = torch.zeros((B, N), device=device)
        
        for b in range(B):
            # Convert to CPU for KDTree (faster for large point clouds)
            pts_np = points[b].cpu().numpy()
            tree = cKDTree(pts_np)
            
            # Find k nearest neighbors for each point
            dists, _ = tree.query(pts_np, k=self.k_neighbors+1)  # +1 to exclude self
            
            # Convert back to tensor
            dists = torch.from_numpy(dists[:, 1:]).to(device)  # Exclude self-distance
            
            # Gaussian KDE
            weights = torch.exp(-0.5 * (dists / self.bandwidth) ** 2)
            density = weights.sum(dim=1) / (self.k_neighbors * (self.bandwidth * np.sqrt(2 * np.pi)))
            densities[b] = density
            
        return densities.squeeze(0) if squeeze else densities
    
    def get_adaptive_weights(self, points, temperature=0.1):
        """
        Compute adaptive weights based on point density.
        
        Args:
            points: Tensor of shape [B, N, 3] or [N, 3]
            temperature: Controls the sharpness of the weight distribution
            
        Returns:
            weights: Tensor of shape [B, N] or [N] with sampling weights
        """
        # Estimate density (higher in dense regions)
        density = self.estimate_point_density(points)  # [B, N] or [N]
        
        # Invert and normalize to sample more from sparse regions
        inv_density = 1.0 / (density + self.eps)
        weights = F.softmax(inv_density / temperature, dim=-1)
        
        return weights
    
    def sample_adaptive_mask(self, points, mask_ratio, temperature=0.1):
        """
        Generate adaptive mask using Halton sequence and point density.
        
        Args:
            points: Tensor of shape [B, N, 3]
            mask_ratio: Fraction of points to mask (0-1)
            temperature: Controls sampling sharpness
            
        Returns:
            mask: Boolean tensor of shape [B, N] where True indicates masked
        """
        B, N, _ = points.shape
        device = points.device
        
        # Get adaptive weights
        weights = self.get_adaptive_weights(points, temperature)  # [B, N]
        
        # Generate Halton sequence in 3D
        halton_seq = self.halton_sampler.sample(N, device)  # [N, 3]
        
        # Project to 1D using random direction
        direction = torch.randn(3, device=device)
        direction = direction / (torch.norm(direction) + self.eps)
        projections = halton_seq @ direction  # [N]
        
        # Sort points by Halton projections
        _, sorted_indices = torch.sort(projections)
        
        # Number of points to mask
        num_masked = int(mask_ratio * N)
        
        # Create base mask using Halton sequence
        base_mask = torch.zeros(N, dtype=torch.bool, device=device)
        base_mask[sorted_indices[:num_masked]] = True
        
        # Apply adaptive sampling
        adaptive_mask = torch.zeros(B, N, dtype=torch.bool, device=device)
        for b in range(B):
            # Sample according to weights
            probs = weights[b] * base_mask.float()
            if probs.sum() > 0:
                probs = probs / probs.sum()
                sampled = torch.multinomial(probs, num_masked, replacement=False)
                adaptive_mask[b, sampled] = True
            else:
                # Fallback to non-adaptive if all weights are zero
                adaptive_mask[b] = base_mask
                
        return adaptive_mask

class Halton3DSampler:
    """Standard 3D Halton sequence generator"""
    def __init__(self, seed=42):
        self.primes = [2, 3, 5]  # First 3 prime numbers
        self.rng = np.random.RandomState(seed)
        
    def sample(self, n_points, device='cuda'):
        """Generate Halton sequence in 3D space"""
        sequence = np.zeros((n_points, len(self.primes)))
        for i, p in enumerate(self.primes):
            n = np.arange(1, n_points + 1)
            r = np.zeros(n_points)
            f = 1.0 / p
            while np.any(n > 0):
                r += f * (n % p)
                n = n // p
                f = f / p
            sequence[:, i] = r
            
        # Random rotation for better coverage
        angles = self.rng.uniform(0, 2*np.pi, 3)
        Rx = np.array([[1, 0, 0],
                      [0, np.cos(angles[0]), -np.sin(angles[0])],
                      [0, np.sin(angles[0]), np.cos(angles[0])]])
        Ry = np.array([[np.cos(angles[1]), 0, np.sin(angles[1])],
                      [0, 1, 0],
                      [-np.sin(angles[1]), 0, np.cos(angles[1])]])
        Rz = np.array([[np.cos(angles[2]), -np.sin(angles[2]), 0],
                      [np.sin(angles[2]), np.cos(angles[2]), 0],
                      [0, 0, 1]])
        rotation = Rz @ Ry @ Rx
        sequence = sequence @ rotation.T
        
        return torch.tensor(sequence, device=device, dtype=torch.float32)
