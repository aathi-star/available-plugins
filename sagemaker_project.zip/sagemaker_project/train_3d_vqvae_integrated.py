"""Optimized 3D Generation Training Script with MaskGIT3D and 3D VQ-VAE"""
import os
import sys
import time
import json
import argparse
import numpy as np
from tqdm import tqdm
from pathlib import Path
from datetime import datetime
from collections import defaultdict
from torch.optim.lr_scheduler import CosineAnnealingLR
import math

import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.distributed as dist
from torch.cuda.amp import GradScaler, autocast
from torch.utils.tensorboard import SummaryWriter

# Add project root to path
sys.path.append(str(Path(__file__).parent.absolute()))

from Network.transformer_3d import MaskGIT3D, Halton3DSampler
from Network.point_vqvae import PointVQVAE, load_pretrained_vqvae
from utils.vq_utils import get_vqvae_model, encode_point_clouds, decode_to_point_clouds
from datasets.modelnet_loader import ModelNet10Dataset

# Add these imports at the top
from torch.optim.lr_scheduler import CosineAnnealingLR
import math

class MaskGITTrainer:
    def __init__(self, args):
        self.args = args
        self.device = torch.device(args.device)
        
        # Initialize models
        self.model, self.vqvae = self._init_models()
        self._setup_optimizers()
        self.scaler = torch.cuda.amp.GradScaler(enabled=args.fp16)
        
        # Training state
        self.current_epoch = 0
        self.best_val_loss = float('inf')
        
    def _init_models(self):
        # Initialize VQ-VAE
        vqvae = PointVQVAE(
            num_points=self.args.num_points,
            embed_dim=self.args.vq_embed_dim,
            codebook_size=self.args.vq_codebook_size
        ).to(self.device)
        
        # Load pre-trained weights
        if self.args.vqvae_ckpt:
            checkpoint = torch.load(self.args.vqvae_ckpt, map_location=self.device)
            vqvae.load_state_dict(checkpoint['model_state_dict'])
            print(f"Loaded VQ-VAE from {self.args.vqvae_ckpt}")
        vqvae.eval()  # Freeze VQ-VAE
        
        # Initialize MaskGIT3D
        model = MaskGIT

def parse_args():
    parser = argparse.ArgumentParser(description='Train MaskGIT3D with 3D VQ-VAE')
    
    # Model parameters
    parser.add_argument('--embed_dim', type=int, default=256, help='Model embedding dimension')
    parser.add_argument('--depth', type=int, default=4, help='Number of transformer layers')
    parser.add_argument('--heads', type=int, default=4, help='Number of attention heads')
    parser.add_argument('--mlp_ratio', type=float, default=4.0, help='MLP ratio in transformer')
    parser.add_argument('--drop_rate', type=float, default=0.1, help='Dropout rate')
    
    # VQ-VAE parameters
    parser.add_argument('--vqvae_ckpt', type=str, default=None, help='Path to pre-trained VQ-VAE checkpoint')
    parser.add_argument('--vq_codebook_size', type=int, default=1024, help='VQ-VAE codebook size')
    parser.add_argument('--vq_embed_dim', type=int, default=256, help='VQ-VAE embedding dimension')
    
    # Training parameters
    parser.add_argument('--batch_size', type=int, default=32, help='Batch size per GPU')
    parser.add_argument('--epochs', type=int, default=300, help='Number of training epochs')
    parser.add_argument('--lr', type=float, default=1e-4, help='Learning rate')
    parser.add_argument('--weight_decay', type=float, default=0.05, help='Weight decay')
    parser.add_argument('--warmup_epochs', type=int, default=10, help='Warmup epochs')
    parser.add_argument('--min_lr', type=float, default=1e-6, help='Minimum learning rate')
    parser.add_argument('--clip_grad', type=float, default=1.0, help='Gradient clipping')
    
    # Masking parameters
    parser.add_argument('--mask_ratio', type=float, default=0.5, help='Masking ratio')
    parser.add_argument('--mask_strategy', type=str, default='halton', 
                        choices=['random', 'halton', 'learned'], help='Masking strategy')
    
    # Dataset parameters
    parser.add_argument('--data_dir', type=str, default='./data/ModelNet10', 
                       help='Path to ModelNet10 dataset')
    parser.add_argument('--num_points', type=int, default=1024, help='Number of points per sample')
    parser.add_argument('--num_workers', type=int, default=4, help='Number of data loading workers')
    
    # Logging and saving
    parser.add_argument('--output_dir', type=str, default='./output', help='Output directory')
    parser.add_argument('--log_dir', type=str, default='./logs', help='Log directory')
    parser.add_argument('--save_freq', type=int, default=10, help='Save frequency (epochs)')
    parser.add_argument('--print_freq', type=int, default=10, help='Print frequency (iterations)')
    
    # System parameters
    parser.add_argument('--device', type=str, default='cuda' if torch.cuda.is_available() else 'cpu',
                       help='Device to use for training')
    parser.add_argument('--seed', type=int, default=42, help='Random seed')
    parser.add_argument('--fp16', action='store_true', help='Use mixed precision training')
    parser.add_argument('--compile', action='store_true', help='Compile model with torch.compile()')
    
    parser.add_argument('--min_mask_ratio', type=float, default=0.3, 
                   help='Minimum mask ratio (start of training)')
    parser.add_argument('--max_mask_ratio', type=float, default=0.9,
                    help='Maximum mask ratio (end of training)')
    parser.add_argument('--grad_accumulation', type=int, default=4,
                    help='Number of gradient accumulation steps')
    parser.add_argument('--early_stop_patience', type=int, default=20,
                    help='Number of epochs to wait before early stopping')

    parser.add_argument('--grad_skip_threshold', type=float, default=1e6,
                    help='Skip batch if gradient norm exceeds this value')
    parser.add_argument('--log_interval', type=int, default=10,
                    help='Log interval in batches')
    return parser.parse_args()

def set_seed(seed):
    """Set all random seeds for reproducibility"""
    torch.manual_seed(seed)
    np.random.seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False

def create_models(args):
    # Load pre-trained VQ-VAE
    vqvae = PointVQVAE(
        num_points=args.num_points,
        embed_dim=args.vq_embed_dim,
        codebook_size=args.vq_codebook_size
    ).to(args.device)
    
    # Load pre-trained weights
    if args.vqvae_ckpt:
        checkpoint = torch.load(args.vqvae_ckpt, map_location=args.device)
        vqvae.load_state_dict(checkpoint['model_state_dict'])
        print(f"Loaded VQ-VAE from {args.vqvae_ckpt}")
    vqvae.eval()  # Freeze VQ-VAE
    
    # Initialize MaskGIT3D with adaptive Halton masking
    model = MaskGIT3D(
        embed_dim=args.embed_dim,
        depth=args.depth,
        num_heads=args.num_heads,
        mlp_ratio=args.mlp_ratio,
        dropout=args.dropout,
        num_classes=args.vq_codebook_size,
        masking_strategy='adaptive_halton'  # Enable adaptive Halton masking
    ).to(args.device)
    
    return model, vqvae
    
    # Initialize MaskGIT3D weights
    def init_weights(m):
        if isinstance(m, nn.Linear):
            nn.init.xavier_uniform_(m.weight)
            if m.bias is not None:
                nn.init.constant_(m.bias, 0)
        elif isinstance(m, nn.LayerNorm):
            nn.init.constant_(m.weight, 1.0)
            nn.init.constant_(m.bias, 0)
    
    model.apply(init_weights)
    
    return model, vqvae

def prepare_dataloaders(args):
    """Prepare training and validation dataloaders"""
    from torch.utils.data import DataLoader
    
    # Create datasets
    train_dataset = ModelNet10Dataset(
        root=args.data_dir,
        split='train',
        num_points=args.num_points,
        use_normalized_coords=True
    )
    
    val_dataset = ModelNet10Dataset(
        root=args.data_dir,
        split='test',
        num_points=args.num_points,
        use_normalized_coords=True
    )
    
    # Create dataloaders
    train_loader = DataLoader(
        train_dataset,
        batch_size=args.batch_size,
        shuffle=True,
        num_workers=args.num_workers,
        pin_memory=True,
        drop_last=True
    )
    
    val_loader = DataLoader(
        val_dataset,
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=args.num_workers,
        pin_memory=True,
        drop_last=False
    )
    
    return train_loader, val_loader

def train_epoch(model, vqvae, criterion, optimizer, scaler, dataloader, epoch, args):
    model.train()
    vqvae.eval()
    
    total_loss = 0.0
    total_items = 0
    accumulated_steps = 0
    
    # Progressive masking schedule
    if epoch < args.epochs * 0.2:  # First 20% of epochs
        mask_ratio = 0.3 + 0.2 * (epoch / (args.epochs * 0.2))  # 0.3 -> 0.5
    elif epoch < args.epochs * 0.8:  # Middle 60% of epochs
        progress = (epoch - args.epochs * 0.2) / (args.epochs * 0.6)
        mask_ratio = 0.5 + 0.25 * progress  # 0.5 -> 0.75
    else:  # Last 20% of epochs
        progress = (epoch - args.epochs * 0.8) / (args.epochs * 0.2)
        mask_ratio = 0.75 + 0.15 * progress  # 0.75 -> 0.9
    
    # Gradient accumulation
    accumulation_steps = args.accumulation_steps
    optimizer.zero_grad()
    
    for batch_idx, batch in enumerate(tqdm(dataloader, desc=f'Epoch {epoch+1}/{args.epochs}')):
        points = batch['points'].to(args.device)
        
        with torch.no_grad():
            codebook_indices = encode_point_clouds(vqvae, points, args.device)
        
        # Forward pass with mixed precision
        with autocast(enabled=args.fp16):
            logits = model(points, mask_ratio=mask_ratio)
            logits = logits.view(-1, logits.size(-1))
            targets = codebook_indices.view(-1).long()
            loss = criterion(logits, targets) / accumulation_steps
        
        # Scale loss for gradient accumulation
        if args.fp16:
            scaler.scale(loss).backward()
        else:
            loss.backward()
        
        # Gradient accumulation
        if (batch_idx + 1) % accumulation_steps == 0 or (batch_idx + 1) == len(dataloader):
            # Gradient clipping
            if args.fp16:
                scaler.unscale_(optimizer)
            
            # Check for exploding gradients
            grad_norm = torch.nn.utils.clip_grad_norm_(
                model.parameters(), 
                args.clip_grad
            )
            
            # Skip batch if gradients are too large
            if grad_norm > args.grad_skip_threshold:
                optimizer.zero_grad()
                print(f'Skipping batch {batch_idx} - Gradient norm too large: {grad_norm:.2f}')
                continue
                
            # Optimizer step
            if args.fp16:
                scaler.step(optimizer)
                scaler.update()
            else:
                optimizer.step()
            
            optimizer.zero_grad()
            accumulated_steps += 1
        
        # Update metrics
        total_loss += loss.item() * accumulation_steps
        total_items += points.size(0)
        
        # Log gradient information
        if (batch_idx + 1) % args.log_interval == 0:
            print(f'Epoch {epoch+1} [{batch_idx+1}/{len(dataloader)}] '
                  f'Loss: {total_loss/total_items:.4f} '
                  f'Grad Norm: {grad_norm:.2f} '
                  f'Mask Ratio: {mask_ratio:.2f}')
    
    return total_loss / total_items if total_items > 0 else 0.0

@torch.no_grad()
def validate(model, vqvae, criterion, dataloader, args):
    """Validate model on validation set"""
    model.eval()
    vqvae.eval()
    
    total_loss = 0.0
    total_items = 0
    
    # Progress bar
    pbar = tqdm(dataloader, desc='Validation', dynamic_ncols=True)
    
    for batch in pbar:
        # Move data to device
        points = batch['points'].to(args.device)  # (B, N, 3)
        
        # Encode point clouds to get codebook indices
        with torch.no_grad():
            # Convert points to voxel grid and get codebook indices
            codebook_indices = encode_point_clouds(vqvae, points, args.device)
            
            # Forward pass
            with autocast(enabled=args.fp16):
                # Predict codebook indices
                logits = model(points)
                
                # Reshape for loss calculation
                B, S, C = logits.shape
                logits = logits.view(-1, C)
                targets = codebook_indices.view(-1).long()
                
                # Calculate loss
                loss = criterion(logits, targets)
        
        # Update metrics
        batch_size = points.size(0)
        total_loss += loss.item() * batch_size
        total_items += batch_size
        
        # Update progress bar
        pbar.set_postfix({'val_loss': f"{total_loss/total_items:.4f}"})
    
    return total_loss / total_items if total_items > 0 else 0.0

def save_checkpoint(state, filename):
    """Save training checkpoint"""
    torch.save(state, filename)

def main():
    # Parse arguments
    args = parse_args()
    parser = argparse.ArgumentParser(description='Train MaskGIT3D with VQ-VAE')
    parser.add_argument('--accumulation_steps', type=int, default=1,
                       help='Number of steps for gradient accumulation')
    parser.add_argument('--grad_skip_threshold', type=float, default=1e6,
                       help='Skip batch if gradient norm exceeds this value')
    parser.add_argument('--log_interval', type=int, default=10,
                       help='Log interval in batches')
    
    # Set random seed
    set_seed(args.seed)
    
    # Create output directories
    os.makedirs(args.output_dir, exist_ok=True)
    os.makedirs(args.log_dir, exist_ok=True)
    
    # Initialize TensorBoard writer
    writer = SummaryWriter(log_dir=args.log_dir)
    
    # Create models
    print("Creating models...")
    model, vqvae = create_models(args)
    
    # Print model summary
    print(f"MaskGIT3D model: {sum(p.numel() for p in model.parameters())/1e6:.2f}M parameters")
    print(f"VQ-VAE model: {sum(p.numel() for p in vqvae.parameters())/1e6:.2f}M parameters")
    
    # Compile model if requested
    if args.compile and hasattr(torch, 'compile'):
        try:
            model = torch.compile(model)
            print("Model successfully compiled with torch.compile()")
        except Exception as e:
            print(f"Warning: Failed to compile model: {e}")
    
    # Prepare dataloaders
    print("Preparing dataloaders...")
    train_loader, val_loader = prepare_dataloaders(args)
    
    # Loss function
    criterion = nn.CrossEntropyLoss()
    
    # Optimizer
    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=args.lr,
        weight_decay=args.weight_decay,
        betas=(0.9, 0.95)
    )

    best_val_loss = float('inf')
    patience_counter = 0
    early_stop = False
    
    for epoch in range(start_epoch, args.epochs):
        if early_stop:
            break
            
        # Train for one epoch
        train_loss = train_epoch(model, vqvae, criterion, optimizer, scaler, 
                               train_loader, epoch, args)
        
        # Validate
        val_loss = validate(model, vqvae, criterion, val_loader, args)
        
        # Learning rate scheduling
        scheduler.step(val_loss)
        
        # Early stopping
        if val_loss < best_val_loss:
            best_val_loss = val_loss
            patience_counter = 0
            # Save best model
            torch.save({
                'epoch': epoch,
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'scheduler_state_dict': scheduler.state_dict(),
                'val_loss': val_loss,
            }, os.path.join(args.output_dir, 'best_model.pth'))
        else:
            patience_counter += 1
            if patience_counter >= args.early_stop_patience:
                print(f"Early stopping after {epoch+1} epochs")
                early_stop = True
        
        # Logging
        writer.add_scalar('Loss/train', train_loss, epoch)
        writer.add_scalar('Loss/val', val_loss, epoch)
        writer.add_scalar('LR', optimizer.param_groups[0]['lr'], epoch)
        writer.add_scalar('Params/mask_ratio', 
                         min_mask_ratio if epoch < args.epochs * 0.2 else 
                         max_mask_ratio if epoch >= args.epochs * 0.8 else
                         min_mask_ratio + (max_mask_ratio - min_mask_ratio) * 
                         ((epoch - args.epochs * 0.2) / (args.epochs * 0.6)),
                         epoch)
        
        # Save checkpoint
        if (epoch + 1) % args.save_freq == 0
    
    # Learning rate scheduler with warmup
    def lr_lambda(current_step):
        # Linear warmup over warmup_epochs
        if current_step < args.warmup_epochs * len(train_loader):
            return float(current_step) / float(max(1, args.warmup_epochs * len(train_loader)))
        # Cosine decay after warmup
        progress = float(current_step - args.warmup_epochs * len(train_loader)) / float(
            max(1, (args.epochs - args.warmup_epochs) * len(train_loader)))
        return 0.5 * (1.0 + math.cos(math.pi * progress))
    
    scheduler = torch.optim.lr_scheduler.LambdaLR(optimizer, lr_lambda)
    
    # Gradient scaler for mixed precision training
    scaler = GradScaler(enabled=args.fp16)
    
    # Training loop
    print("Starting training...")
    best_val_loss = float('inf')
    
    for epoch in range(args.epochs):
        # Train for one epoch
        train_loss = train_epoch(
            model, vqvae, criterion, optimizer, scaler, 
            train_loader, epoch, args
        )
        
        # Validate
        val_loss = validate(
            model, vqvae, criterion, val_loader, args
        )
        
        # Update learning rate
        scheduler.step()
        
        # Log metrics
        writer.add_scalar('train/loss', train_loss, epoch)
        writer.add_scalar('val/loss', val_loss, epoch)
        writer.add_scalar('lr', optimizer.param_groups[0]['lr'], epoch)
        
        # Save checkpoint
        is_best = val_loss < best_val_loss
        best_val_loss = min(best_val_loss, val_loss)
        
        if (epoch + 1) % args.save_freq == 0 or is_best or (epoch == args.epochs - 1):
            checkpoint = {
                'epoch': epoch,
                'state_dict': model.state_dict(),
                'optimizer': optimizer.state_dict(),
                'scheduler': scheduler.state_dict(),
                'scaler': scaler.state_dict(),
                'best_val_loss': best_val_loss,
                'args': args
            }
            
            # Save checkpoint
            checkpoint_path = os.path.join(args.output_dir, f'checkpoint_epoch_{epoch+1:04d}.pth')
            save_checkpoint(checkpoint, checkpoint_path)
            
            if is_best:
                best_path = os.path.join(args.output_dir, 'model_best.pth')
                torch.save(checkpoint, best_path)
    
    # Close TensorBoard writer
    writer.close()
    print("Training completed!")

if __name__ == '__main__':
    main()



"""
python train_3d_vqvae_integrated.py \
    --vqvae_ckpt checkpoints/vqvae/vqvae_best.pth \
    --data_dir /path/to/ModelNet10 \
    --output_dir checkpoints/maskgit \
    --batch_size 16 \
    --epochs 300 \
    --lr 1e-4 \
    --warmup_epochs 10 \
    --mask_ratio 0.5 \
    --mask_strategy adaptive_halton \
    --vq_codebook_size 1024 \
    --vq_embed_dim 256 \
    --fp16 \
    --clip_grad 1.0
"""