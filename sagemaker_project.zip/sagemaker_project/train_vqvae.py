# train_vqvae.py
import os
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
from tqdm import tqdm
import numpy as np
from torch.optim.lr_scheduler import ReduceLROnPlateau
from torch.utils.tensorboard import SummaryWriter
from Network.point_vqvae import PointVQVAE
from datasets.modelnet_loader import ModelNet10Dataset
import torch.nn.functional as F

class EarlyStopping:
    def __init__(self, patience=10, delta=0, path='checkpoint.pt', verbose=False):
        self.patience = patience
        self.delta = delta
        self.path = path
        self.verbose = verbose
        self.counter = 0
        self.best_score = None
        self.early_stop = False
        self.val_loss_min = np.Inf

    def __call__(self, val_loss, model):
        score = -val_loss

        if self.best_score is None:
            self.best_score = score
            self.save_checkpoint(val_loss, model)
        elif score < self.best_score + self.delta:
            self.counter += 1
            if self.verbose:
                print(f'EarlyStopping counter: {self.counter} out of {self.patience}')
            if self.counter >= self.patience:
                self.early_stop = True
        else:
            self.best_score = score
            self.save_checkpoint(val_loss, model)
            self.counter = 0

    def save_checkpoint(self, val_loss, model):
        if self.verbose:
            print(f'Validation loss decreased ({self.val_loss_min:.6f} --> {val_loss:.6f}). Saving model...')
        torch.save(model.state_dict(), self.path)
        self.val_loss_min = val_loss

def train_vqvae(args):
    # Initialize models and data loaders
    device = torch.device(args.device)
    model = PointVQVAE(
        num_points=args.num_points,
        embed_dim=args.embed_dim,
        codebook_size=args.codebook_size
    ).to(device)
    
    # Optimizer and scheduler
    optimizer = optim.AdamW(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    scheduler = ReduceLROnPlateau(optimizer, 'min', patience=args.lr_patience, factor=0.5, verbose=True)
    early_stopping = EarlyStopping(patience=args.early_stop_patience, verbose=True, 
                                 path=f'{args.output_dir}/best_model.pth')
    
    # Data loading
    train_dataset = ModelNet10Dataset(root=args.data_dir, split='train', num_points=args.num_points)
    val_dataset = ModelNet10Dataset(root=args.data_dir, split='test', num_points=args.num_points)
    
    train_loader = DataLoader(train_dataset, batch_size=args.batch_size, shuffle=True, 
                            num_workers=args.num_workers, pin_memory=True)
    val_loader = DataLoader(val_dataset, batch_size=args.batch_size, shuffle=False,
                          num_workers=args.num_workers, pin_memory=True)
    
    # Training loop
    for epoch in range(args.epochs):
        model.train()
        train_loss = 0.0
        
        # Training phase
        for batch in tqdm(train_loader, desc=f'Epoch {epoch+1}/{args.epochs}'):
            points = batch['points'].to(device)
            
            # Forward pass
            quantized, codebook_loss, _ = model(points)
            recon_loss = F.mse_loss(quantized, points)
            loss = recon_loss + args.beta * codebook_loss
            
            # Backward pass
            optimizer.zero_grad()
            loss.backward()
            
            # Gradient clipping
            torch.nn.utils.clip_grad_norm_(model.parameters(), args.clip_grad)
            
            optimizer.step()
            train_loss += loss.item()
        
        # Validation phase
        val_loss = 0.0
        model.eval()
        with torch.no_grad():
            for batch in val_loader:
                points = batch['points'].to(device)
                quantized, codebook_loss, _ = model(points)
                recon_loss = F.mse_loss(quantized, points)
                val_loss += (recon_loss + args.beta * codebook_loss).item()
        
        # Update learning rate
        avg_train_loss = train_loss / len(train_loader)
        avg_val_loss = val_loss / len(val_loader)
        scheduler.step(avg_val_loss)
        
        # Early stopping
        early_stopping(avg_val_loss, model)
        if early_stopping.early_stop:
            print("Early stopping triggered")
            break
            
        # Logging
        print(f'Epoch {epoch+1}: Train Loss: {avg_train_loss:.6f}, Val Loss: {avg_val_loss:.6f}')

if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--data_dir', type=str, required=True, help='Path to ModelNet10 dataset')
    parser.add_argument('--output_dir', type=str, default='outputs/vqvae')
    parser.add_argument('--batch_size', type=int, default=32)
    parser.add_argument('--num_points', type=int, default=1024)
    parser.add_argument('--embed_dim', type=int, default=256)
    parser.add_argument('--codebook_size', type=int, default=1024)
    parser.add_argument('--lr', type=float, default=2e-4)
    parser.add_argument('--weight_decay', type=float, default=1e-4)
    parser.add_argument('--beta', type=float, default=0.25)
    parser.add_argument('--epochs', type=int, default=500)
    parser.add_argument('--clip_grad', type=float, default=1.0)
    parser.add_argument('--lr_patience', type=int, default=10)
    parser.add_argument('--early_stop_patience', type=int, default=30)
    parser.add_argument('--num_workers', type=int, default=4)
    parser.add_argument('--device', type=str, default='cuda' if torch.cuda.is_available() else 'cpu')
    args = parser.parse_args()
    
    os.makedirs(args.output_dir, exist_ok=True)
    train_vqvae(args)